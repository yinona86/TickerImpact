import Results from '../Results';

export default function ResultsExample() {
  return <Results />;
}
